const express = require('express');
const router = express.Router();

const paymentTermController = require('./paymentTerm.controller');
const { verifyAccessToken } = require('../../core/middlewares/auth.middleware');
const { authorizeRoles } = require('../../core/middlewares/role.middleware');

router.get(
  '/',
  verifyAccessToken,
  authorizeRoles('SALE','PRODUCT_MANAGER'),
  paymentTermController.findAllActive
);

module.exports = router;
