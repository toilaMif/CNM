const paymentTermService = require('./paymentTerm.service');

exports.findAllActive = async (req, res) => {
  try {
    const terms = await paymentTermService.findAllActive();
    return res.json({ success: true, data: terms });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};
