const { pool } = require('../../config/database');

exports.findAllActive = async () => {
  const [rows] = await pool.execute(
    `
    SELECT 
      payment_term_template_id,
      term_name,
      description,
      credit_days,
      early_commission_rate_per_day,
      late_interest_rate_per_day
    FROM payment_term_templates
    WHERE is_active = 1
    ORDER BY credit_days ASC, payment_term_template_id ASC
    `
  );

  return rows;
};
