const paymentTermRepository = require('./paymentTerm.repository');

exports.findAllActive = async () => {
  return paymentTermRepository.findAllActive();
};
